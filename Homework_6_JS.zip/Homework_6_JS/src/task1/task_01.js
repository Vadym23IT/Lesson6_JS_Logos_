function Robot() {
	this.name = 'Robot';
	this.occupation = 'Я Robot – я просто працюю';
}

Robot.prototype.work = function() {
	console.log("Я " + this.name + ' - ' + this.occupation);
}

function CoffeeRobot() {
	this.name = "Coffee Robot";
	this.occupation = "Я CoffeRobot – я варю каву";
}
CoffeeRobot.prototype = Object.create(Robot.prototype);
CoffeeRobot.prototype.constructor = CoffeeRobot;

function DancerRobot() {
	this.name = "Robot Dancer";
	this.occupation = "Я RobotDancer – я просто танцюю";
}
DancerRobot.prototype = Object.create(Robot.prototype);
DancerRobot.prototype.constructor = DancerRobot;

function CookerRobot() {
	this.name = "Robot Cooker";
	this.occupation = "Я RobotCoocker – я просто готую";
}
CookerRobot.prototype = Object.create(Robot.prototype);
CookerRobot.prototype.constructor = CookerRobot;

let robot = new Robot();
robot.work();
let coffeeRobot = new CoffeeRobot();
coffeeRobot.work();
let dancerRobot = new DancerRobot();
dancerRobot.work();
let cookerRobot = new CookerRobot();
cookerRobot.work();

console.log('')

let Robots = [robot, coffeeRobot, dancerRobot, cookerRobot];
for (let i = 0; i < Robots.length; i++) {
	Robots[i].work();
}